# Jarvis v1 — Offline Voice Assistant

Ye Jarvis ka pehla version hai: aik Android app jo **baghair internet ke** tumhari awaz sunti hai,
"Jarvis" naam par jaagti hai, aur tumhare hukum par **app kholti hai** aur **call lagati hai**.
Ye sirf tumhare hukum par chalti hai — apni marzi se kuch nahi karti, aur isme video upload
waghera ka koi kaam hai hi nahi.

## Ye kya karta hai (v1)

- "Jarvis" bolo -> Jarvis jaag jata hai aur "Yes?" bolta hai
- Phir 10 second ke andar hukum bolo:
  - "WhatsApp kholo" / "open WhatsApp" -> wo app khul jayegi
  - "Ammi ko call karo" / "call Ammi" -> us contact ko call lag jayegi
  - Aik hi jumle mein bhi chalega: "Jarvis, WhatsApp kholo"
- "Jarvis stop" ya "Jarvis band karo" -> Jarvis band ho jata hai

## Ye kya nahi karta (seedhi baat)

- Free-form baat-cheet nahi karta — sirf upar wale fixed hukum maanta hai.
- Video upload, message bhejna, payment, delete — ye sab isme nahi hai.
- Offline pehchan online jitni saaf nahi hoti — shor mein ya ghuma phira kar bolne par
  ghalti ho sakti hai. Saaf aur fixed jumle bolo to sab se behtar chalega.
- Hamesha sunne se battery zyada kharch hogi — ye normal hai, iska hal neeche hai.

## Chahiye

- Aik computer (Windows/Mac/Linux) jis par **Android Studio** ho
- Tumhara Android phone + USB cable (ya APK file phone mein copy karne ka koi tareeqa)
- Pehli dafa offline language pack download karne ke liye thoda internet
  (uske baad Jarvis baghair internet ke chalega)

## Banane ke steps

1. Computer par Android Studio install karo: https://developer.android.com/studio
2. Android Studio kholo -> **New Project** -> **Empty Views Activity** -> naam "Jarvis" rakho,
   language **Kotlin**, minimum SDK **API 26** (Android 8.0) -> Finish.
3. Is project ki files ko apne naye project mein copy karo:
   - `settings.gradle`, `build.gradle`, `gradle.properties` -> project ki root mein
   - `app/build.gradle` -> `app/` folder mein
   - `app/src/main/AndroidManifest.xml` -> `app/src/main/` mein
   - `app/src/main/java/com/jarvis/assistant/` ki saari `.kt` files ->
     `app/src/main/java/com/jarvis/assistant/` mein (folder banana ho to bana lo)
   - `app/src/main/res/layout/activity_main.xml` -> `app/src/main/res/layout/` mein
   - `app/src/main/res/values/strings.xml` -> `app/src/main/res/values/` mein
   - Note: app ka icon (`@mipmap/ic_launcher`) Android Studio ke template se mil jayega,
     usko chherne ki zaroorat nahi.
4. Android Studio mein **Sync** hone do (Gradle files download hongi — is step mein internet chahiye).
5. **Build > Build App Bundle(s) / APK(s) > Build APK(s)** par click karo.
   APK ban jayegi: `app/build/outputs/apk/debug/app-debug.apk`
6. Wo APK phone mein copy karo aur install karo. Phone poochega to "Install unknown apps"
   ki ijazat do (ye sirf apni banayi hui app ke liye hai).
7. App kholo -> **Jarvis Shuru Karo** dabao. Ye permissions maangega:
   - Microphone (awaz sunne ke liye)
   - Call (call lagane ke liye)
   - Contacts (contact ka number dhoondne ke liye)
   - Notification (ye batane ke liye ke Jarvis chal raha hai)
   - "Display over other apps" (background se app kholne ke liye — ye na di to
     Android app kholne se rok dega)
8. **Battery optimization off karo** (warna Android Jarvis ko band kar dega):
   Settings -> Apps -> Jarvis -> Battery -> **Unrestricted** select karo.
9. **Offline language pack** (aik dafa, internet se):
   Google app -> Settings -> Voice -> Offline speech recognition ->
   **English (US)** download karo. (Agar tum Urdu mein bolna chahte ho to code mein
   `JarvisService.kt` mein `SPEECH_LANGUAGE` ko `"ur-PK"` kar do aur Urdu ka pack download karo.)
10. Test karo: "Jarvis" bolo -> "Yes?" suno -> "WhatsApp kholo" bolo.
    App ke andar log mein likha aayega ke Jarvis ne kya suna aur kya kiya.

## Commands ki list (v1)

| Tum bolo | Jarvis karega |
|---|---|
| Jarvis | Jaag jayega, "Yes?" bolega |
| Jarvis, WhatsApp kholo | WhatsApp kholega |
| Jarvis, call Ammi | Ammi ko call lagayega |
| Jarvis stop / Jarvis band karo | Band ho jayega |

Note: app aur contact ke naam phone mein **Roman/English** mein hone chahiye
(masalan contact "Ammi" ke naam se save ho). Urdu script wale naam v1 nahi pehchanta.

## Agar kuch na chale to

- **Jarvis nahi jaagta:** mic ki permission check karo, zor se aur saaf "Jarvis" bolo,
  aur dekho ke notification mein "Jarvis sun raha hai" likha ho.
- **App nahi khulti:** app ka naam wahi bolo jo phone mein likha hai
  (masalan "WhatsApp", poora naam). "Display over other apps" ki ijazat check karo.
- **Call nahi lagti:** CALL_PHONE permission check karo, aur contact ka naam Roman mein save karo.
- **Service khud band ho jati hai:** battery ko "Unrestricted" karo (step 8).
- **Awaz ki pehchan online ho rahi hai:** offline pack download karo (step 9).
- **Kuch samajh nahi aata:** app ka log kholo — usme likha hoga ke Jarvis ne kya suna tha.

## Safety aur usool

- Jarvis sirf tumhare bole hue hukum par amal karta hai. Koi kaam apni marzi se nahi hota.
- Call lagane se pehle wo bol kar batata hai ke kisko call kar raha hai ("Calling Ammi").
- Ye app sirf zaati istemal ke liye hai. Isme `QUERY_ALL_PACKAGES` permission is liye hai
  taake wo apps ke naam pehchan sake — Play Store par aisi app publish karna mushkil hota hai,
  is liye ise sirf apne phone par istemal karo.

## Agla version (v2) mein kya aa sakta hai

- Porcupine jaisa asli wake-word engine (kam battery, zyada reliable "Jarvis" pehchan)
- Call lagane se pehle tasdeeq ("Ammi ko call karun?" -> "Han")
- Zyada hukum: alarm, message parhna, flashlight, music
- Tumhare bataye hue aur commands
