package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Installed apps mein se naam se app dhoond kar kholta hai.
 */
object AppHelper {

    fun launchAppByName(context: Context, query: String): Boolean {
        val target = TextUtil.normalize(query)
        if (target.isBlank()) return false

        val pm = context.packageManager
        var bestPkg: String? = null
        var bestScore = 0.0

        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (app in apps) {
            // Sirf wo apps jo khul sakti hain (launcher wali)
            pm.getLaunchIntentForPackage(app.packageName) ?: continue
            val label = TextUtil.normalize(pm.getApplicationLabel(app).toString())
            if (label.isBlank()) continue
            val score = when {
                label == target -> 1.0
                label.contains(target) || target.contains(label) -> 0.9
                else -> TextUtil.similarity(label, target)
            }
            if (score > bestScore) {
                bestScore = score
                bestPkg = app.packageName
            }
        }

        if (bestPkg == null || bestScore < 0.6) return false

        val intent = pm.getLaunchIntentForPackage(bestPkg)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } ?: return false

        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
