package com.jarvis.assistant

import android.content.Context

data class CommandResult(val feedback: String)

/**
 * Bole hue jumle ko hukum mein badalta hai.
 * v1 mein sirf fixed hukum hain:
 *   - "open <app>" / "<app> kholo"  -> app kholo
 *   - "call <naam>"                -> call lagao
 * Koi bhi kaam tumhare hukum ke baghair nahi hota, aur
 * isme video upload waghera ka koi kaam hai hi nahi.
 */
object CommandParser {

    /** Kya ye jumla kisi hukum jaisa lag raha hai? (wake word ke saath aik hi jumle ke liye) */
    fun looksLikeCommand(text: String): Boolean {
        val t = text.lowercase()
        return t.contains("open") || t.contains("kholo") || t.contains("khol") ||
            t.contains("call") || t.contains("stop") || t.contains("band karo")
    }

    fun parse(rawText: String, context: Context): CommandResult {
        var text = rawText.lowercase().trim()
        text = removeWords(text, listOf("jarvis", "please", "zara"))

        return when {
            text.contains("call") -> handleCall(text, context)
            text.contains("open") || text.contains("kholo") || text.contains("khol") ->
                handleOpen(text, context)
            else -> CommandResult("Samajh nahi aaya. Dobara bolo: app kholo ya call karo.")
        }
    }

    private fun handleOpen(text: String, context: Context): CommandResult {
        var name = removeWords(text, listOf("open", "kholo", "khol", "app", "ko"))
        name = name.trim().replace(Regex("\\s+"), " ")
        if (name.isBlank()) return CommandResult("Kaunsi app kholun? Naam bolo.")
        val launched = AppHelper.launchAppByName(context, name)
        return if (launched) CommandResult("Opening $name")
        else CommandResult("$name naam ki app nahi mili.")
    }

    private fun handleCall(text: String, context: Context): CommandResult {
        var name = removeWords(text, listOf("call", "karo", "ko", "lagao"))
        name = name.trim().replace(Regex("\\s+"), " ")
        if (name.isBlank()) return CommandResult("Kisko call karun? Naam bolo.")
        return ContactHelper.callContact(context, name)
    }

    /** Sirf poore lafz hatata hai, taake "Komal" jaisa naam na toote. */
    private fun removeWords(text: String, words: List<String>): String {
        var out = " $text "
        for (w in words) {
            out = out.replace(Regex("\\b" + Regex.escape(w) + "\\b"), " ")
        }
        return out.replace(Regex("\\s+"), " ").trim()
    }
}
