package com.jarvis.assistant

/**
 * Naam milane ke liye chhote tools.
 * Note: ye v1 sirf Roman/English haroof se milata hai, is liye
 * app aur contact ke naam phone mein Roman mein hone chahiye
 * (masalan "WhatsApp", "Ammi").
 */
object TextUtil {

    /** Text ko milane ke qabil banata hai: chhote haroof, sirf haroof aur adad. */
    fun normalize(s: String): String =
        s.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** Do lafzon ki milawat 0.0 se 1.0 tak (1.0 = bilkul aik jaisa). */
    fun similarity(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val dist = levenshtein(a, b)
        return 1.0 - dist.toDouble() / maxOf(a.length, b.length)
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[a.length][b.length]
    }
}
