package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/**
 * Contacts mein se naam se number dhoond kar call lagata hai.
 * Call mobile network se lagti hai (ye internet nahi hai).
 */
object ContactHelper {

    fun callContact(context: Context, query: String): CommandResult {
        val target = TextUtil.normalize(query)
        if (target.isBlank()) return CommandResult("Kisko call karun? Naam bolo.")

        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return CommandResult("Contacts parhne ki permission nahi hai.")
        }

        var bestName: String? = null
        var bestNumber: String? = null
        var bestScore = 0.0

        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        try {
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                val nameIdx =
                    cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx =
                    cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx).orEmpty() else ""
                    val number = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else ""
                    if (name.isBlank() || number.isBlank()) continue
                    val label = TextUtil.normalize(name)
                    if (label.isBlank()) continue
                    val score = when {
                        label == target -> 1.0
                        label.contains(target) || target.contains(label) -> 0.9
                        else -> TextUtil.similarity(label, target)
                    }
                    if (score > bestScore) {
                        bestScore = score
                        bestName = name
                        bestNumber = number
                    }
                }
            }
        } catch (e: Exception) {
            return CommandResult("Contacts kholne mein ghalti hui.")
        }

        if (bestName == null || bestNumber == null || bestScore < 0.6) {
            return CommandResult("$query naam ka contact nahi mila.")
        }

        val number = bestNumber!!.replace(Regex("[^0-9+]"), "")
        val intent = if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CALL_PHONE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
        } else {
            // Permission na ho to dialer khol do, call user khud lagaye
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
        }.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

        return try {
            context.startActivity(intent)
            CommandResult("Calling $bestName")
        } catch (e: Exception) {
            CommandResult("Call lagane mein ghalti hui.")
        }
    }
}
