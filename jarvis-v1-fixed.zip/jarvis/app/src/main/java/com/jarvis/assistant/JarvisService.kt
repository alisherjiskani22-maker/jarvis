package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

/** App ke andar log dikhane ke liye (sirf isi app mein, bahar kuch nahi jata). */
object JarvisLog {
    var listener: ((String) -> Unit)? = null
    fun add(msg: String) {
        Log.d("Jarvis", msg)
        listener?.invoke(msg)
    }
}

/**
 * Jarvis ki asli service: background mein awaz sunti hai.
 *
 * Tareeqa (2 step, taake offline pehchan reliable rahe):
 *   1. "Jarvis" bolo -> service jaag jati hai, "Yes?" bolti hai.
 *   2. 10 second ke andar hukum bolo: "WhatsApp kholo" ya "Ammi ko call karo".
 * Aik hi jumle mein bhi chalega: "Jarvis, WhatsApp kholo".
 *
 * Internet: awaz ki pehchan ke liye EXTRA_PREFER_OFFLINE use hota hai,
 * is liye pehli dafa offline language pack download hona chahiye
 * (README mein tareeqa likha hai). Uske baad ye baghair internet ke chalta hai.
 * Call mobile network se lagti hai, jo internet nahi hai.
 */
class JarvisService : Service() {

    companion object {
        const val CHANNEL_ID = "jarvis_channel"
        const val NOTIFICATION_ID = 1

        // Pehchanne ki zuban. "en-US" is liye rakhi hai kyunke commands mein
        // English lafz (open, call, WhatsApp) hote hain.
        // Agar tum poori Urdu mein bolna chahte ho to ise "ur-PK" kar do
        // aur uska offline pack download karo.
        const val SPEECH_LANGUAGE = "en-US"

        const val WAKE_WORD = "jarvis"

        // Wake word ke baad hukum sunne ka waqt
        const val COMMAND_TIMEOUT_MS = 10_000L
    }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var listeningForCommand = false
    private var isRunning = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var commandTimeoutRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Jarvis sun raha hai..."))
        if (!isRunning) {
            isRunning = true
            startListening()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        commandTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------- Sunna ----------------

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            JarvisLog.add("Speech recognition is device par available nahi hai.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                // Ghalti ya khamoshi par dobara sunna shuru karo
                restartListening()
            }

            override fun onResults(results: Bundle?) {
                val heard = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (heard.isNotBlank()) handleHeard(heard)
                restartListening()
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, SPEECH_LANGUAGE)
            // Offline pehchan ko tarjeeh do
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e("Jarvis", "startListening failed", e)
        }
    }

    private fun restartListening() {
        // Thoda waqfa taake system dobara tayyar ho jaye
        mainHandler.postDelayed({ if (isRunning) startListening() }, 300)
    }

    // ---------------- Samajhna aur amal ----------------

    private fun handleHeard(heard: String) {
        JarvisLog.add("Suna: $heard")
        val text = heard.lowercase(Locale.ROOT)

        if (!listeningForCommand) {
            if (text.contains(WAKE_WORD)) {
                val remainder = text.replace(WAKE_WORD, " ").trim()
                if (remainder.isNotBlank() && CommandParser.looksLikeCommand(remainder)) {
                    // "Jarvis, WhatsApp kholo" — aik hi jumle mein hukum
                    executeCommand(remainder)
                } else {
                    listeningForCommand = true
                    speak("Yes?")
                    JarvisLog.add("Jarvis jaag gaya — hukum ka intezar hai.")
                    updateNotification("Jarvis jaag gaya — hukum do.")
                    scheduleCommandTimeout()
                }
            }
            return
        }

        // Hukum sunne wali halat mein hain
        executeCommand(text)
    }

    private fun executeCommand(raw: String) {
        cancelCommandTimeout()
        listeningForCommand = false
        updateNotification("Jarvis sun raha hai...")

        val text = raw.lowercase(Locale.ROOT)
        if (text.contains("stop") || text.contains("band karo") || text.contains("ruk jao")) {
            speak("Goodbye")
            JarvisLog.add("Jarvis band ho raha hai.")
            mainHandler.postDelayed({ stopSelf() }, 1500)
            return
        }

        val result = CommandParser.parse(raw, this)
        speak(result.feedback)
        JarvisLog.add(result.feedback)
    }

    private fun scheduleCommandTimeout() {
        cancelCommandTimeout()
        val r = Runnable {
            listeningForCommand = false
            updateNotification("Jarvis sun raha hai...")
        }
        commandTimeoutRunnable = r
        mainHandler.postDelayed(r, COMMAND_TIMEOUT_MS)
    }

    private fun cancelCommandTimeout() {
        commandTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        commandTimeoutRunnable = null
    }

    // ---------------- Awaz aur notification ----------------

    private fun speak(text: String) {
        try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-utterance")
        } catch (e: Exception) {
            Log.e("Jarvis", "TTS failed", e)
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Jarvis",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Jarvis sun raha hai" }
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }
}
