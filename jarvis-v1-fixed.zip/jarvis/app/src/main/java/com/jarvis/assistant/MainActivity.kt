package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Jarvis ki main screen: shuru/band karne ka button aur log.
 * Asli kaam JarvisService mein hota hai.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var logText: TextView

    private val permissions = if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.POST_NOTIFICATIONS
        )
    } else {
        arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) {
                startJarvis()
            } else {
                statusText.text = "Status: permissions ke baghair Jarvis nahi chalega."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        logText = findViewById(R.id.logText)

        findViewById<Button>(R.id.btnStart).setOnClickListener { checkPermissionsAndStart() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { stopJarvis() }

        JarvisLog.listener = { msg ->
            runOnUiThread { logText.append("\n$msg") }
        }
    }

    override fun onDestroy() {
        JarvisLog.listener = null
        super.onDestroy()
    }

    private fun checkPermissionsAndStart() {
        // Background se app kholne/call lagane ke liye "Display over other apps"
        // ki ijazat zaroori hai, warna Android rok deta hai.
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Jarvis ko 'Display over other apps' ki ijazat do, phir dobara Start dabao.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            startJarvis()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startJarvis() {
        val intent = Intent(this, JarvisService::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        statusText.text = "Status: Jarvis chal raha hai — 'Jarvis' bolo, phir hukum do."
    }

    private fun stopJarvis() {
        stopService(Intent(this, JarvisService::class.java))
        statusText.text = "Status: band hai"
    }
}
